﻿Public Class frmSuperMarketProduct
    Private Sub frmSuperMarketProduct_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Supermarket_DBDataSet.tblProduct' table. You can move, or remove it, as needed.
        Me.TblProductTableAdapter.Fill(Me.Supermarket_DBDataSet.tblProduct)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        TblProductBindingSource.MoveNext()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        TblProductBindingSource.MovePrevious()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        TblProductBindingSource.MoveFirst()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TblProductBindingSource.MoveLast()
    End Sub

    Private Sub frmSuperMarketProduct_Resize(sender As Object, e As EventArgs) Handles Me.Resize
        ' DataGridView1.Height = Height - 10
        DataGridView1.Width = Width - 10
        'DataGridView1.ScrollBars = Enabled

    End Sub
End Class
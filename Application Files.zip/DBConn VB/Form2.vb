﻿Public Class frmCourse
    Private Sub CourseBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) 
        Me.Validate()
        Me.CourseBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.STUDDBDataSet1)

    End Sub

    Private Sub frmCourse_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'STUDDBDataSet1.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.STUDDBDataSet1.Course)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        CourseBindingSource.MoveFirst()
    End Sub

    Private Sub btnPrev_Click(sender As Object, e As EventArgs) Handles btnPrev.Click
        CourseBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        CourseBindingSource.MoveNext()
    End Sub

    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        CourseBindingSource.MoveLast()
    End Sub
End Class
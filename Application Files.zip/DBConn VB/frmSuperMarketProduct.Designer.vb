﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSuperMarketProduct
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.TblProductBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Supermarket_DBDataSet = New DBConn_VB.Supermarket_DBDataSet()
        Me.TblProductTableAdapter = New DBConn_VB.Supermarket_DBDataSetTableAdapters.tblProductTableAdapter()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.PCodeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PNameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PTypeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.UPriceDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExpdateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QuantityinstokeDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblProductBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Supermarket_DBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PCodeDataGridViewTextBoxColumn, Me.PNameDataGridViewTextBoxColumn, Me.PTypeDataGridViewTextBoxColumn, Me.UPriceDataGridViewTextBoxColumn, Me.MDateDataGridViewTextBoxColumn, Me.ExpdateDataGridViewTextBoxColumn, Me.QuantityinstokeDataGridViewTextBoxColumn})
        Me.DataGridView1.DataSource = Me.TblProductBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(13, 13)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(1242, 425)
        Me.DataGridView1.TabIndex = 0
        '
        'TblProductBindingSource
        '
        Me.TblProductBindingSource.DataMember = "tblProduct"
        Me.TblProductBindingSource.DataSource = Me.Supermarket_DBDataSet
        '
        'Supermarket_DBDataSet
        '
        Me.Supermarket_DBDataSet.DataSetName = "Supermarket_DBDataSet"
        Me.Supermarket_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblProductTableAdapter
        '
        Me.TblProductTableAdapter.ClearBeforeFill = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(34, 481)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 36)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Next"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(211, 481)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(106, 36)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "Previous"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(413, 481)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(101, 35)
        Me.Button3.TabIndex = 3
        Me.Button3.Text = "First"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(605, 481)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(117, 34)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Last"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'PCodeDataGridViewTextBoxColumn
        '
        Me.PCodeDataGridViewTextBoxColumn.DataPropertyName = "PCode"
        Me.PCodeDataGridViewTextBoxColumn.HeaderText = "Product Code"
        Me.PCodeDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.PCodeDataGridViewTextBoxColumn.Name = "PCodeDataGridViewTextBoxColumn"
        Me.PCodeDataGridViewTextBoxColumn.Width = 125
        '
        'PNameDataGridViewTextBoxColumn
        '
        Me.PNameDataGridViewTextBoxColumn.DataPropertyName = "PName"
        Me.PNameDataGridViewTextBoxColumn.HeaderText = "Product Name"
        Me.PNameDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.PNameDataGridViewTextBoxColumn.Name = "PNameDataGridViewTextBoxColumn"
        Me.PNameDataGridViewTextBoxColumn.Width = 125
        '
        'PTypeDataGridViewTextBoxColumn
        '
        Me.PTypeDataGridViewTextBoxColumn.DataPropertyName = "PType"
        Me.PTypeDataGridViewTextBoxColumn.HeaderText = "Product Type"
        Me.PTypeDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.PTypeDataGridViewTextBoxColumn.Name = "PTypeDataGridViewTextBoxColumn"
        Me.PTypeDataGridViewTextBoxColumn.Width = 125
        '
        'UPriceDataGridViewTextBoxColumn
        '
        Me.UPriceDataGridViewTextBoxColumn.DataPropertyName = "UPrice"
        Me.UPriceDataGridViewTextBoxColumn.HeaderText = "Unit Price"
        Me.UPriceDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.UPriceDataGridViewTextBoxColumn.Name = "UPriceDataGridViewTextBoxColumn"
        Me.UPriceDataGridViewTextBoxColumn.Width = 125
        '
        'MDateDataGridViewTextBoxColumn
        '
        Me.MDateDataGridViewTextBoxColumn.DataPropertyName = "MDate"
        Me.MDateDataGridViewTextBoxColumn.HeaderText = "Manufature Date"
        Me.MDateDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.MDateDataGridViewTextBoxColumn.Name = "MDateDataGridViewTextBoxColumn"
        Me.MDateDataGridViewTextBoxColumn.Width = 125
        '
        'ExpdateDataGridViewTextBoxColumn
        '
        Me.ExpdateDataGridViewTextBoxColumn.DataPropertyName = "Exp_date"
        Me.ExpdateDataGridViewTextBoxColumn.HeaderText = "Expired Date"
        Me.ExpdateDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.ExpdateDataGridViewTextBoxColumn.Name = "ExpdateDataGridViewTextBoxColumn"
        Me.ExpdateDataGridViewTextBoxColumn.Width = 125
        '
        'QuantityinstokeDataGridViewTextBoxColumn
        '
        Me.QuantityinstokeDataGridViewTextBoxColumn.DataPropertyName = "quantity_in_stoke"
        Me.QuantityinstokeDataGridViewTextBoxColumn.HeaderText = "Quantity In Stoke"
        Me.QuantityinstokeDataGridViewTextBoxColumn.MinimumWidth = 6
        Me.QuantityinstokeDataGridViewTextBoxColumn.Name = "QuantityinstokeDataGridViewTextBoxColumn"
        Me.QuantityinstokeDataGridViewTextBoxColumn.Width = 125
        '
        'frmSuperMarketProduct
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1263, 545)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "frmSuperMarketProduct"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Product List"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblProductBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Supermarket_DBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Supermarket_DBDataSet As Supermarket_DBDataSet
    Friend WithEvents TblProductBindingSource As BindingSource
    Friend WithEvents TblProductTableAdapter As Supermarket_DBDataSetTableAdapters.tblProductTableAdapter
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents PCodeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PNameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PTypeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents UPriceDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents MDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ExpdateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents QuantityinstokeDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class

﻿Public Class frmConCode
    'Connection parameter
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.Ace.OleDB.12.0; Data source=D:\Visual Studio Project\STUDDB.accdb")
    Dim cmd As New OleDb.OleDbCommand
    'SQL Command String
    Dim SQL As String

    Private Sub btnConnection_Click(sender As Object, e As EventArgs) Handles btnConnection.Click
        Try
            con.Open()
            If con.State = ConnectionState.Open Then
                MsgBox("Connection successful!")
            Else
                MsgBox("Connection Failed!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            con.Open()
            SQL = txtQuery.Text
            cmd.Connection = con
            cmd.CommandText = SQL
            DA.SelectCommand = cmd
            DA.Fill(DT)
            dgv.DataSource = DT
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        Try
            con.Open()
            SQL = "INSERT INTO Course VALUES('" & txtCoNumber.Text & "','" & txtTitle.Text & "'," & Val(txtCrHr.Text) & "," & Val(txtCoHr.Text) & ")"
            cmd.Connection = con
            cmd.CommandText = SQL
            If cmd.ExecuteNonQuery > 0 Then
                MsgBox("Record has been inserted successfully!")
            Else
                MsgBox("No record has been inserted!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Dim cn As String
        Try
            con.Open()
            cn = InputBox("Enter course number of the course to be deleted")
            SQL = "DELETE * FROM Course WHERE CNO='" & cn & "'"
            cmd.Connection = con
            cmd.CommandText = SQL
            If cmd.ExecuteNonQuery > 0 Then
                MsgBox("Record has been Deleted successfully!")
            Else
                MsgBox("No record has been inserted!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub txtCoNumber_TextChanged(sender As Object, e As EventArgs) Handles txtCoNumber.TextChanged
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            con.Open()
            SQL = "SELECT * FROM Course WHERE CNO LIKE '%" & txtCoNumber.Text & "%'"
            cmd.Connection = con
            cmd.CommandText = SQL
            DA.SelectCommand = cmd
            DA.Fill(DT)
            dgv.DataSource = DT
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim CN As String
        Try
            con.Open()
            CN = InputBox("Enter course number to be updated")
            SQL = "UPDATE Course SET CNO='" & txtCoNumber.Text & "', Title='" & txtTitle.Text & "',Credit=" & Val(txtCrHr.Text) & ", Contact=" & Val(txtCoHr.Text) & " WHERE CNO='" & CN & "'"
            cmd.Connection = con
            cmd.CommandText = SQL
            If cmd.ExecuteNonQuery > 0 Then
                MsgBox("Record has been updated successfully!")
            Else
                MsgBox("No record has been inserted!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtQuery.Clear()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            con.Open()
            'SQL = txtQuery.Text
            SQL = txtQuery.Text
            cmd.Connection = con
            cmd.CommandText = SQL
            DA.SelectCommand = cmd
            DA.Fill(DT)
            dgv.DataSource = DT
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub
End Class
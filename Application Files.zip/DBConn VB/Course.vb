﻿Public Class Course
    Private Sub Course_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'STUDDBDataSet3.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.STUDDBDataSet3.Course)

    End Sub
End Class
﻿Public Class frmItems
    Private Sub frmItems_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'STUDDBDataSet2.Items' table. You can move, or remove it, as needed.
        Me.ItemsTableAdapter.Fill(Me.STUDDBDataSet2.Items)

    End Sub
End Class
﻿Public Class Lbirary_DB
    Dim conn As New OleDb.OleDbConnection("Provider=Microsoft.Ace.OleDb.12.0; Data source=D:\Visual Studio Project\LibraryDB.accdb")
    Dim cmd As New OleDb.OleDbCommand
    Dim SQL As String
    Private Sub Lbirary_DB_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'LibraryDBDataSet.STUDENT' table. You can move, or remove it, as needed.
        Me.STUDENTTableAdapter.Fill(Me.LibraryDBDataSet.STUDENT)
    End Sub

    Private Sub Library_DB_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Are You Sure?", "Confirm", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        Try
            conn.Open()
            SQL = "SELECT b.TITLE, b.AUTHOR, bo.ISSUEDATE, bo.DUEDATE FROM BOOK b INNER JOIN BORROW bo ON b.ISBN=bo.ISBN WHERE IDNO='" & ComboBox1.Text & "'"
            cmd.Connection = conn
            cmd.CommandText = SQL
            DA.SelectCommand = cmd
            DA.Fill(DT)
            DataGridView1.DataSource = DT
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim Grade As New frmGrade
        Grade.ShowDialog()
    End Sub

End Class
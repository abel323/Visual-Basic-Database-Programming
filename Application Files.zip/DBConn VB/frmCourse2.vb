﻿Public Class frmCourse2
    Private Sub CourseBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CourseBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.CourseBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.STUDDBDataSet1)

    End Sub

    Private Sub frmCourse2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'STUDDBDataSet1.Course' table. You can move, or remove it, as needed.
        Me.CourseTableAdapter.Fill(Me.STUDDBDataSet1.Course)

    End Sub

    Private Sub btnFirst_Click(sender As Object, e As EventArgs) Handles btnFirst.Click
        CourseBindingSource.MoveFirst()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        CourseBindingSource.MovePrevious()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        CourseBindingSource.MoveNext()
    End Sub

    Private Sub btnLast_Click(sender As Object, e As EventArgs) Handles btnLast.Click
        CourseBindingSource.MoveLast()
    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        CourseBindingSource.AddNew()

    End Sub

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        Try
            CourseBindingSource.EndEdit()
            CourseTableAdapter.Update(STUDDBDataSet1.Course)
            MsgBox("Record has been saved successfully!")
        Catch ex As Exception
            MsgBox("Error! Record has not been saved!")
        End Try
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        CourseBindingSource.RemoveCurrent()
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            CourseBindingSource.EndEdit()
            TableAdapterManager.UpdateAll(STUDDBDataSet1)
            MsgBox("Record has been updated successfully!")
        Catch ex As Exception
            MsgBox("Error! Record has not been updated!")
        End Try
    End Sub
End Class
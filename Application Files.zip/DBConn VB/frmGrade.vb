﻿Public Class frmGrade
    Dim con As New OleDb.OleDbConnection("Provider=Microsoft.Ace.OleDB.12.0; Data source=D:\Visual Studio Project\STUDENTDB.accdb")
    Dim cmd As New OleDb.OleDbCommand
    'SQL Command String
    Dim SQL As String
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim DA As New OleDb.OleDbDataAdapter
        Dim DT As New DataTable
        ' Dim SQL1 As String
        ' Dim Name As String
        Try
            con.Open()
            SQL = "SELECT course.CONO, course.TITLE, course.CREDIT, course.CONTACT, take.GRADE FROM COURSE 
            course INNER JOIN TAKE take ON course.CONO = take.CONO WHERE IDNO='" & cboIDNO.Text & "'"
            'SQL = "SELECT course.CONO, TITLE, CREDIT, CONTACT, GRADE FROM STUDENT INNER JOIN(TAKE INNER JOIN COURSE on TAKE.CONO= course.CONO) ON student.IFNO=take.IDNO WHERE STUDENT.IDNO='" & cboIDNO.Text & "'"
            'SQL1 = "SELECT NAME FROM STUDENT WHERE IDNO='" & cboIDNO.Text & "'"
            cmd.Connection = con
            cmd.CommandText = SQL
            DA.SelectCommand = cmd
            DA.Fill(DT)
            dgvDetail.DataSource = DT
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub frmGrade_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO:   This line of code loads data into the STUDENTDBDataSet.STUDENT' table. You can move, or remove it, as needed.
        Me.STUDENTTableAdapter.Fill(Me.STUDENTDBDataSet.STUDENT)

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtID.Clear()
        txtCourseNumber.Clear()
        txtGrade.Clear()
        txtID.Select()
    End Sub

    Private Sub btnInsert_Click(sender As Object, e As EventArgs) Handles btnInsert.Click
        Try
            con.Open()
            SQL = "INSERT INTO TAKE VALUES('" & txtID.Text & "','" & txtCourseNumber.Text & "','" & txtGrade.Text & "')"
            cmd.Connection = con
            cmd.CommandText = SQL
            If cmd.ExecuteNonQuery > 0 Then
                MsgBox("Data inserted successfully!")
            Else
                MsgBox("No data has been inserted!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim ID As String
        Dim cono As String
        Try
            con.Open()
            ID = InputBox("Enter Student ID")
            cono = InputBox("Enter Course Number")
            SQL = "UPDATE TAKE SET GRADE='" & txtGrade.Text & "' WHERE IDNO='" & ID & "' AND CONO='" & cono & "'"
            cmd.Connection = con
            cmd.CommandText = SQL
            If cmd.ExecuteNonQuery > 0 Then
                MsgBox("Data updated successfully!")
            Else
                MsgBox("No data is updated!")
            End If
        Catch ex As Exception
            MsgBox(ex.Message())
        Finally
            con.Close()
        End Try
    End Sub

End Class